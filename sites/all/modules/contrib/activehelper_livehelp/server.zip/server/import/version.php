<?php              
include_once('constants.php');

$web_application_version = '1.1';
$web_application_revision = 'Rev. 1';

$windows_application_version = '1.0';

$velaio_copyright_label = '<a href="http://www.activehelper.com" target="_blank" class="normlink">ACTIVEHELPER Platform</a> All Rights Reserved';
$velaio_livehelp_version_label = 'Live Help Server Version: ' . $web_application_version . ' ' . $web_application_revision;

?>
