<?php         
include_once('constants.php');

?>
<script language="JavaScript" type="text/JavaScript">
<!--
// Session Authentication Error Occurred Redirect to Login Page
top.location.href = '<?php echo $install_directory; ?>/panel/index.php?STATUS=authentication';
//-->
</script>

