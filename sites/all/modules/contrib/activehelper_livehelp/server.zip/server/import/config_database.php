<?php

if ( !defined( '__CONFIG_DATABASE_INC' ) ) {
	define( '__CONFIG_DATABASE_INC', 1 );
	define( 'DS', DIRECTORY_SEPARATOR );

	include_once('constants.php');
	include_once('jlhconst.php');

	define( "DB_HOST", "{__db_host__}" );
	define( "DB_USER", "{__db_user__}" );
	define( "DB_PASS", "{__db_pass__}" );
	define( "DB_NAME", "{__db_name__}" );

	$table_prefix = '{__db_prefix__}';
	$table_prefix = $table_prefix . 'livehelp_';
}

?>