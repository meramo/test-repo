<?php 
include_once('constants.php');

?>
<script language="JavaScript" type="text/JavaScript" src="<?php echo($site_address); ?><?php echo $install_directory; ?>/import/javascript.php"></script>
