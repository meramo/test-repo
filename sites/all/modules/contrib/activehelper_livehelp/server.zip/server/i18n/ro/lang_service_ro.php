<?php

  $seconds = 'Secunde';
  $session_expired = 'Sesiunea CHAT SERVICIUL CLIENTI expira in ';
  $session_expired = 'Sesiunea CHAT SERVICIUL CLIENTI va expira in ';
  $password_incorrect = 'Parola este incorecta';
  $login_account_incorrect = 'Informatiile introduse sunt incorecte';

  $unavailable_label = 'Nedisponibil';
  $initiated_default_label = 'Cererea catre CHAT SERVICIUL CLIENTI nu a fost initiata.';
  $initiated_sending_label = 'Trimiterea cererii dvs catre CHAT SERVICIUL CLIENTI este in curs...';
  $initiated_waiting_label = 'In curs de asteptare pentru raspunsul de initiere ...';
  $initiated_accepted_label = 'Cererea Dvs pentru initierea CHAT SERVICIUL CLIENTI a fost ACCEPTATA';
  $initiated_declined_label = 'Cererea Dvs pentru initierea CHAT SERVICIUL CLIENTI a fost RESPINSA';
  $initiated_chatting_label = 'Acum vorbiti cu un Agent din departamentul SERVICIUL CLIENTI';
  $initiated_chatted_label = 'Ati mai discutat cu un Agent SERVICIUL CLIENTI';
  $initiated_pending_label = 'In asteptare pentru CHAT SERVICIUL CLIENTI';
  $current_request_referrer_result = 'Vizita Directa / Bookmark';  

?>

