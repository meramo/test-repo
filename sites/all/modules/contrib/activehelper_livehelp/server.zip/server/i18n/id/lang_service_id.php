<?php

  $seconds = 'Detik';
  $session_expired = 'La session de Livehelp esta activa. La sesion expirara en ';
  $session_expired = 'Percakapan Live Help sudah aktif. Percakapan akan berakhir dalam';
  $password_incorrect = 'Password Salah';
  $login_account_incorrect = 'Login atau Account Salah';

  $unavailable_label = 'Tidak Ada';
  $initiated_default_label = 'Permintaan percakapan Live Help belum dilakukan';
  $initiated_sending_label = 'Kirim permintaan percakapan Live Help ...';
  $initiated_waiting_label = 'Tunggu untuk memulai percakapan Live Help ...';
  $initiated_accepted_label = 'Permintaan percakapan Live Help berhasil';
  $initiated_declined_label = 'Permintaan percakapan Live Help gagal';
  $initiated_chatting_label = 'Saat ini percakapan dengan operator';
  $initiated_chatted_label = 'Sedang berbicara dengan operator';
  $initiated_pending_label = 'Saat ini percakapan Live Help tertunda';
  $current_request_referrer_result = 'Kunjungi / Bookmark';  

?>

