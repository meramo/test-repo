<?php

  $seconds = 'ثانیه';
  $session_expired = 'La session de Livehelp esta activa. La sesion expirara en ';
  $session_expired = 'این پنجره فعال است و بسته خواهد شد در  ';
  $password_incorrect = 'پسورد اشتباه است';
  $login_account_incorrect = 'نام کاربری صحیح نیست';

  $unavailable_label = 'در دسترس نیست';
  $initiated_default_label = 'پشتیبانی آنلاین هنوز شروع نشده است';
  $initiated_sending_label = 'در حال ارسال درخواست اولیه';
  $initiated_waiting_label = 'منتظر دریافت پاسخ اولیه...';
  $initiated_accepted_label = 'درخواست اولیه مورد تایید قرار گرفت';
  $initiated_declined_label = 'درخواست اولیه رد شد';
  $initiated_chatting_label = 'در حال گفتگو با اوپراتور';
  $initiated_chatted_label = 'با یک اوپراتور گفتگو کرده است';
  $initiated_pending_label = 'در حال انتظار برای گفتگوی آنلاین';
  $current_request_referrer_result = 'بوکمارک ';  

?>

