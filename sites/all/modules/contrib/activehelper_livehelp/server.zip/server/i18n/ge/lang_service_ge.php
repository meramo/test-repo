<?php

  $seconds = 'წამები';
  $session_expired = 'ონლაინ სასაუბრო აქტიურია. სასაუბრო დასრულდება ';
  $password_incorrect = 'პაროლი არასწორია';
  $schedule_time_incorrect ='ამჟამად შესვლა შეუძლებელია';
  $login_account_incorrect = 'ლოგინი ან ანგარიში არასწორია';

  $unavailable_label = 'დაკავშირება შეუძლებელია';
  $initiated_default_label = 'ონლაინ დახმარების მოთხოვნა არ იქნა მიღებული';
  $initiated_sending_label = '–ონლაინ დახმარების დაწყებაზე მოთხოვნის გაგზავნა...';
  $initiated_waiting_label = 'ონლაინ დახმარების სასაუბროს დაწყების ლოდინი...';
  $initiated_accepted_label = 'ონლაინ დახმარების დაწყების მოთხოვნა მიღებულია';
  $initiated_declined_label = 'ონლაინ დახმარების დაწყების მოთხოვნის უარყოფილია';
  $initiated_chatting_label = 'ამჟამად ესაუბრებით ოპერატორს';
  $initiated_chatted_label = 'უკვე ესაუბრეთ ოპერატორს';
  $initiated_pending_label = 'ამჟამად მიმდინარეობს ონლაინ დახმარებასთან დაკავშირება';
  $current_request_referrer_result = 'პირდაპირი შესვლა/ამ გვერდის დამახსოვრება';  

?>

