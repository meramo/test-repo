<?php

  $seconds = 'Sekund';
  $session_expired = 'Seja za pogovor s svetovalcem je aktivna. Seja bo potekla čez ';
  $password_incorrect = 'Napačno geslo';
  $login_account_incorrect = 'Uporabniško ime ali račun ni pravi';

  $unavailable_label = 'Ni na voljo';
  $initiated_default_label = 'Zahtevek za pogovor s svetovalcem ni bil začet';
  $initiated_sending_label = 'Pošiljam zahtevek za začetek pogovora s svetovalcem...';
  $initiated_waiting_label = 'Čakam odgovor na zahtevek za začetek pogovora s svetovalcem...';
  $initiated_accepted_label = 'Zahtevek za pogovor s svetovalcem je bil SPREJET';
  $initiated_declined_label = 'Zahtevek za pogovor s svetovalcem je bil ZAVRNJEN';
  $initiated_chatting_label = 'Trenutno se pogovarjate z operaterjem';
  $initiated_chatted_label = 'Pogovarjali ste se že z operaterjem';
  $initiated_pending_label = 'Trenutno čakajo na pogovor s svetovalcem';
  $current_request_referrer_result = 'Neposredni obisk / Zaznamek';  

?>

