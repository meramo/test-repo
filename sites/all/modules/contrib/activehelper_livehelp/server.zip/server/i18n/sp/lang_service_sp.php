<?php
 header("Content-type: text/html; charset=utf-8");

  $seconds = 'Segundos';
  $session_expired = 'La sesión de Livehelp esta activa. La sesión expirara en ';
  $password_incorrect = 'Contraseña incorrecta';
  $schedule_time_incorrect ='Aceso no permitido en este momento';
  $login_account_incorrect = 'Usuario o cuenta incorrecta';

  $unavailable_label = 'No disponible';
  $initiated_default_label = 'Invitación de ayuda en vivo no ha sido iniciada';
  $initiated_sending_label = 'Enviando invitación de ayuda en vivo...';
  $initiated_waiting_label = 'Esperando respuesta de invitación de ayuda en vivo...';
  $initiated_accepted_label = 'Invitación de ayuda en vivo fue aceptada';
  $initiated_declined_label = 'Invitación de ayuda en vivo fue rechazada';
  $initiated_chatting_label = 'Actualmente hablando con un operador';
  $initiated_chatted_label = 'Ya fue atendido por un operador';
  $initiated_pending_label = 'Actualmente pendiente por ayuda en vivo';
  $current_request_referrer_result = 'Visita directa / Favoritos - Bookmark';
?>

