<?php

header("Content-type: text/html; charset=utf-8");

  $seconds = 'Secondi';
  $session_expired = 'La sessione di Livehelp è attiva. La sessione terminerà tra ';
  $session_expired = 'La sessione di Livehelp è attiva. La sessione terminerà tra ';
  $password_incorrect = 'Password NON corretta';
  $schedule_time_incorrect ='Accesso non consentito in questo momento';
  $login_account_incorrect = 'Login o account non corretti';

  $unavailable_label = 'non disponibile';
  $initiated_default_label = 'Live Help Request non è stato inizializzato';
  $initiated_sending_label = 'Sto inviando la richiesta di inizializzazione di Live Help Request...';
  $initiated_waiting_label = 'In attesa di risposta da Live Help Reply...';
  $initiated_accepted_label = 'La richiesta a Live Help Request è stata ACCETTATA ';
  $initiated_declined_label = 'La richiesta a Live Help Request NON E STATA ACCETTATA';
  $initiated_chatting_label = 'Stati chattando con l operatore';
  $initiated_chatted_label = 'Stai già chattando con un operatore';
  $initiated_pending_label = 'In attesa per Live Help';
  $current_request_referrer_result = 'Visita Diretta / Segnalibro';

?>

