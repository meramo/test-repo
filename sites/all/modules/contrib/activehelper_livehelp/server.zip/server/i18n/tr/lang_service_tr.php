<?php

  $seconds = 'Seconds';
  $session_expired = 'La session de Livehelp esta activa. La sesion expirara en ';
  $session_expired = 'Live Help görüsmesi etkin. Görüsmenin sonlandirilma süresi ';
  $password_incorrect = 'Hatali Sifre';
  $login_account_incorrect = 'Hatali kullanici adi veya hesap';

  $unavailable_label = 'Erisilemiyor';
  $initiated_default_label = 'Live Help istegi henüz baslatilmadi';
  $initiated_sending_label = 'Live Help istegi gönderiliyor ...';
  $initiated_waiting_label = 'Live Help istegine yanit bekleniyor...';
  $initiated_accepted_label = 'Live Help istegi KABUL EDILDI';
  $initiated_declined_label = 'Live Help istegi REDDEDILDI';
  $initiated_chatting_label = 'Su anda operatör ile konusuyorsunuz';
  $initiated_chatted_label = 'Bir Operatör ile zaten görüstü';
  $initiated_pending_label = 'Hala Live Help için beklemede';
  $current_request_referrer_result = 'Dogrudan Ziyaret / Yer imi';  

?>

