<?php

  $seconds = 'Sekunder';
  $session_expired = 'Chattsession är aktiverad, denna kommer avslutas om ';
  $password_incorrect = 'Fel lösenord';
  $login_account_incorrect = 'Ditt användarnamn eller dina uppgifter är fel';

  $unavailable_label = 'Inte tillgänglig';
  $initiated_default_label = 'Chattbegäran har inte blivit initierad';
  $initiated_sending_label = 'Skickar initiering...';
  $initiated_waiting_label = 'Väntar på chattinitiering...';
  $initiated_accepted_label = 'Chattinitiering har blivit accepterad';
  $initiated_declined_label = 'Chattinitiering har blivit nekad';
  $initiated_chatting_label = 'Chattar just nu med operatör';
  $initiated_chatted_label = 'Har redan chattat med operatör';
  $initiated_pending_label = 'Väntar just nu på chattsupport';
  $current_request_referrer_result = 'Direktbesök / Bokmärken';  

?>

