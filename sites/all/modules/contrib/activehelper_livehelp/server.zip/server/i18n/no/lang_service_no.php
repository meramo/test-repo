<?php

  $seconds = 'Seconds';
  $session_expired = 'La session de Livehelp esta activa. La sesion expirara en ';
  $session_expired = 'Livehelp økten er aktiv. Sesjonen vil være utløpt om ';
  $password_incorrect = 'Feil passord ';
  $login_account_incorrect = 'Logg inn eller feil konto';

  $unavailable_label = 'Utilgjengelig';
  $initiated_default_label = 'Live forespørsel om hjelp er ikke igangsatt';
  $initiated_sending_label = 'Sende Initiere Live forespørsel om hjelp...';
  $initiated_waiting_label = 'Venter på Start Live Help Svar...';
  $initiated_accepted_label = 'Initiere Live forespørsel om hjelp ble akseptert';
  $initiated_declined_label = 'Initiere Live forespørsel om hjelp ble avvist';
  $initiated_chatting_label = 'Nåværende samtale med Operatør';
  $initiated_chatted_label = 'Allerede snakket med en Operatør';
  $initiated_pending_label = 'venter på Live Hjelp';
  $current_request_referrer_result = 'Direkte Besøk / bokmerker';  

?>

