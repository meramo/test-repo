<?php

  $seconds = 'Seconden';
  $session_expired = 'De LiveHelp sessie is actief. De sessie wordt beeindigd in ';
  $password_incorrect = 'wachtwoord verkeerd';
  $login_account_incorrect = 'Login of account incorrect';
  $schedule_time_incorrect ='Toegang niet toegestaan ??op dit moment';
  $unavailable_label = 'niet beschikbaar';
  $initiated_default_label = 'Live Help verzoek is niet geinitieerd';
  $initiated_sending_label = 'De Live Help Verzoek initiatie wordt verstuurd...';
  $initiated_waiting_label = 'Wachtende op de Live Help antwoord initiatie  ...';
  $initiated_accepted_label = 'Live Help verzoek initiatie werd AANVAARD';
  $initiated_declined_label = 'Live Help verzoek initiatie is GEWEIGERD';
  $initiated_chatting_label = 'U chat nu met Operator';
  $initiated_chatted_label = 'U chatte reeds met een Operator';
  $initiated_pending_label = 'U bent wachtende voor Live Help';
  $current_request_referrer_result = 'Direct Bezoek / Bookmark';  

?>

