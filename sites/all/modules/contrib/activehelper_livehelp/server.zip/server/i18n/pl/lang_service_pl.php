<?php

  $seconds = 'sekund';
  $session_expired = 'Sesja wygas³a';
  $session_expired = 'Sesja aktywna. Sesja wygaœnie za';
  $password_incorrect = 'Niew³aœciwe has³o';
  $login_account_incorrect = 'Niew³aœciwy Login lub nazwa konta';

  $unavailable_label = 'Niedostêpne';
  $initiated_default_label = '¯¹danie Live Help nie zosta³o zainicjowane';
  $initiated_sending_label = 'Wysy³anie ¿¹dania rozpoczêcia Live Help...';
  $initiated_waiting_label = 'Oczekiwanie na odpowiedŸ Live Help...';
  $initiated_accepted_label = '¯¹danie rozpoczêcia Live Help ZAAKCEPTOWANE';
  $initiated_declined_label = '¯¹danie rozpoczêcia Live Help ODRZUCONE';
  $initiated_chatting_label = 'Obecnie rozmawiasz z operatorem';
  $initiated_chatted_label = 'Odby³a siê rozmowa z operatorem';
  $initiated_pending_label = 'Oczekujesz obecnie na Live Help';
  $current_request_referrer_result = 'Direct Visit / Bookmark'; 

?>

