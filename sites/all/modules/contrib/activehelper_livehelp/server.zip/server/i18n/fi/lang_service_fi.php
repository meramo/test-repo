<?php

  $seconds = 'Sekuntia';
  $session_expired = 'La session de Livehelp esta activa. La sesion expirara en ';
  $session_expired = 'Livehelp sessio on aktiivinen. Sessio vanhentuu ';
  $schedule_time_incorrect ='P��sy kielletty t�ll� hetkell�';
  $password_incorrect = 'V&auml;&auml;r&auml; salasana';
  $login_account_incorrect = 'Login tai tili virheellinen';

  $unavailable_label = 'Ei saatavilla';
  $initiated_default_label = 'Live Help pyynt&ouml;&auml; ei ole l&auml;hetty';
  $initiated_sending_label = 'L&auml;hett&auml;&auml; tuen avaus pyynt&ouml;&auml;...';
  $initiated_waiting_label = 'Odottaa tuen avauspyynn&ouml;n vastausta...';
  $initiated_accepted_label = 'Tukipyynn&ouml;n avaus ONNISTUI';
  $initiated_declined_label = 'Tukipyynn&ouml;n avaus EI ONNISTUNUT';
  $initiated_chatting_label = 'Keskustelu k&auml;ynniss&auml; operaattorin kanssa';
  $initiated_chatted_label = 'Keskustelu yhteys operaattoriin on jo olemassa';
  $initiated_pending_label = 'Odottaa Live Help palvelua';
  $current_request_referrer_result = 'Suora yhteys / Kirjanmerkki';

?>

