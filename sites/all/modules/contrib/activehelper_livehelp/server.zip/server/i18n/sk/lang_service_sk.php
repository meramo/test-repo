<?php

  $seconds = 'Sekúnd';
  $session_expired = 'Platnos stránky vypršala ';
  $session_expired = 'Online chat je aktívny. Stránka vyexpiruje za ';
  $password_incorrect = 'Neplatné heslo';
  $login_account_incorrect = 'Meno alebo úèet nie je platný';

  $unavailable_label = 'Nedostupné';
  $initiated_default_label = 'Požiadavka na online chat nebola vznesená';
  $initiated_sending_label = 'Odosielanie požiadavky na zaèatie chatu...';
  $initiated_waiting_label = 'Èakanie na odpoveï online podpory...';
  $initiated_accepted_label = 'Požiadavka na zaèatie online chatu bola AKCEPTOVANÁ';
  $initiated_declined_label = 'Požiadavka na zaèatie online chatu bola ZAMIETNUTÁ';
  $initiated_chatting_label = 'Komunikujete s operátorom';
  $initiated_chatted_label = 'Už ste komunikovali s operátorom';
  $initiated_pending_label = 'Èakáte na online podporu';
  $current_request_referrer_result = 'Priama návšteva / Bookmark';  

?>

